/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function() {
    $("#main_page a").click(function() {
        
        $(this).toggleClass("changeable");
        
        if($(this).attr("class") !== "changeable") {
            $(this).prev().hide();  
        }else {
            $(this).prev().show();
        } 
        
    });
});
