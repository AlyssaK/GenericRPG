package servlets;

import business.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Alyssa
 */
public class LoadBattleServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        Random rand = new Random();
        String msg = "";
        String URL = "/battle_screen.jsp";
        int opp_level;
        int opp_id = rand.nextInt(41) + 1;
        
        List<Action> allActions = (List<Action>) request.getSession().getAttribute("allActions");
        ArrayList<Action> playerActions = new ArrayList<>();
        ArrayList<Action> compActions = new ArrayList<>();
        
        Account a = (Account) request.getSession().getAttribute("acct");        
        Champion activeChamp = a.getActiveChamp();
        Opponent activeOpp = Opponent_DB.findOpponent(opp_id);        
        
        int activeChampID = Integer.parseInt(request.getParameter("active"));
        String diff_level = request.getParameter("actiontype2");       
        
        //Check For Change in Player's Active Champ && Reset Active Champ
        if(activeChamp.getId() != (activeChampID)){
            for(Champion c : a.getChampions()){
                if(c.getId() == activeChampID){
                    activeChamp = c;
                }
            }
        }
        
        a.setActiveChamp(activeChamp);
        a.setActiveChampID(activeChampID);        
        
        //Set Opp Level Based On Difficulty Level && Player Level         
        opp_level = a.getActiveChamp().getChar_Level();      
        if(diff_level.equalsIgnoreCase("apprentice")){
            opp_level++;
        }else if(diff_level.equalsIgnoreCase("master")){
            opp_level+=2;
        }else if(diff_level.equalsIgnoreCase("boss")){
            opp_level+=3;
        }
        activeOpp.setDiff_level(diff_level);
        activeOpp.setChar_Level(opp_level);
        
        //Load Player & Computer Action Tables
        for (Action act : allActions) {
            if(act.getActionID() == activeChamp.getActionID1()){ playerActions.add(act); }
            if(act.getActionID() == activeChamp.getActionID2()){ playerActions.add(act); }
            if(act.getActionID() == activeChamp.getActionID3()){ playerActions.add(act); }
            if(act.getActionID() == activeChamp.getActionID4()){ playerActions.add(act); }
        }
        
        allActions.stream().map((act) -> {
            if(act.getActionID() == activeOpp.getActionID1()){ compActions.add(act); }
            return act;
        }).map((act) -> {
            if(act.getActionID() == activeOpp.getActionID2()){ compActions.add(act); }
            return act;
        }).map((act) -> {
            if(act.getActionID() == activeOpp.getActionID3()){ compActions.add(act); }
            return act;
        }).filter((act) -> (act.getActionID() == activeOpp.getActionID4())).forEachOrdered((act) -> {
            compActions.add(act);
        });
        
        //Instantiate Battle Object
        activeChamp.buildCombatant();
        activeOpp.buildCombatant();
        Battle currBattle = new Battle(activeChamp, activeOpp, playerActions, compActions);
        
        request.setAttribute("msg", msg);
        request.getSession().setAttribute("acct", a);
        request.getSession().setAttribute("allActions", allActions);        
        request.getSession().setAttribute("currBattle", currBattle);
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
