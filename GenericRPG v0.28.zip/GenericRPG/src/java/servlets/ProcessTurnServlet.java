package servlets;

import business.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Alyssa
 */
public class ProcessTurnServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String URL = "/activeBattleScreen.jsp";
        String err_msg = "";
        String plyr_move_stats = "";
        String comp_move_stats = "";
        String win_msg = "";
        String exp_msg = "";
        boolean charLeveled = false;
        boolean accLeveled = false;
        boolean didCrit = false;
        Random rand = new Random();
        int toHit = rand.nextInt(50) + rand.nextInt(50);
        int toCrit = rand.nextInt(50) + rand.nextInt(50);
        int compPercentHP;
        int plyrPercentHP;
        
        List<LevelXPObject> levelXPTable = (List<LevelXPObject>) request.getSession().getAttribute("levelXPTable");
        Battle currBattle = (Battle) request.getSession().getAttribute("currBattle");
        Account a = (Account) request.getSession().getAttribute("acct");
        Action currPlayerAction = null;
        Action currCompAction = currBattle.getCompActions().get(rand.nextInt(4));
        
        //Attempt to Get && Parse player action position
        try{
            currPlayerAction = currBattle.getPlayerActions().get(Integer.parseInt(request.getParameter("actiontype2")));
        }catch(NumberFormatException e){
            err_msg += "GeneralError-1: " + e.getMessage() + "<br>";
        }      
        
        //Load Current Move Choice into Battle Class
        if(currPlayerAction != null){
            currBattle.setPlayer_curr_move(currPlayerAction);
            currBattle.setComp_curr_move(currCompAction);
        }else{
            err_msg += "Action Was Not Retrieved Properly. <br>";
        }
        
        if(err_msg.isEmpty()){
            //Apply Alters
            currBattle.applyAlterPlayer();
            currBattle.applyAlterOpponent();        

            //Check if Applied Alters change FirstStrike
            currBattle.firstStrike();

            //Load Last Known HP into Temp Object
            int currCompHP = currBattle.getComp_curr_hp();
            int currPlyrHP = currBattle.getPlayer_curr_hp();        
            
            //Check Turn: Player = True && Computer == False
            if(currBattle.isTurn()){       
                //Check the Players Hit Chance And Compare to random generated toHit value
                //IF Greater Than Or Equal To The Player's Attack Lands
                if(currBattle.getPlayerHit() >= toHit){
                    //Set The Temp 
                    int plyrDMG = currBattle.getDamageDone();
                    int plyrHEALZ = currBattle.getHealsDone();
                    plyr_move_stats = "The Attack Landed!<br>";

                    if(currBattle.getPlayerCrit() >= toCrit){
                        plyrDMG += currBattle.getPlayer().getBaseCritDmgBonus();
                        plyr_move_stats += "Critical Strike! <br>"
                            + "Crit Ratio: " + currBattle.getPlayer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                            + "Crit DMG: " + currBattle.getPlayer().getBaseCritDmgBonus() + "DMG <br>";                   
                    }

                    if(plyrDMG>0){                 
                        currBattle.setComp_curr_hp(currCompHP - plyrDMG);
                        plyr_move_stats += "Your attack did " + plyrDMG + " DMG! " +"<br>"
                        + "Base DMG: " + currBattle.getPlayer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getPlayer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getPlayer().getBaseDodgePercent() + "% <br>";
                    }                
                    if(plyrHEALZ>0){
                         currBattle.setPlayer_curr_hp(currPlyrHP + plyrHEALZ);
                         plyr_move_stats += "You healed for " + plyrHEALZ + " Health Points!<br>";
                    }                     
                }else{
                    plyr_move_stats += "You missed.<br>"
                        + "Base DMG: " + currBattle.getPlayer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getPlayer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getPlayer().getBaseDodgePercent() + "% <br>"
                        + "Crit Ratio: " + currBattle.getPlayer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                        + "Crit DMG: " + currBattle.getPlayer().getBaseCritDmgBonus() + "DMG <br>";
                }

                plyr_move_stats += "<br> Strength: " + currBattle.getPlayer().getStr() 
                    + " xxx Accuracy: " + currBattle.getPlayer().getAcc() + "<br>"
                    + "Speed: " + currBattle.getPlayer().getSpeed()
                    + " xxxxx Skill: " + currBattle.getPlayer().getSkill() + "<br>"
                    + " x Knowledge: " + currBattle.getPlayer().getKnow() + " x <br>";

                currBattle.setTurn(false);
            }else{
                if(currBattle.getComputerHit() >= toHit){
                    int CompDMG = currBattle.getDamageDone();
                    int CompHEALZ = currBattle.getHealsDone();
                    comp_move_stats += "The Attack Landed!<br>";

                    if(currBattle.getComputerCrit() >= toCrit){                    
                        CompDMG += currBattle.getComputer().getBaseCritDmgBonus();
                        comp_move_stats += "Critical Strike! <br>"
                            + "Crit Ratio: " + currBattle.getComputer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                            + "Crit DMG: " + currBattle.getComputer().getBaseCritDmgBonus() + "DMG <br>";                    
                    }

                    if(CompDMG>0){ 
                        currBattle.setPlayer_curr_hp(currPlyrHP - CompDMG);
                        comp_move_stats += "Computer attack did " + CompDMG + " DMG! " +"<br>"
                            + "Base DMG: " + currBattle.getComputer().getBaseDmg() + "DMG <br>"
                            + "Hit Ratio : " + currBattle.getComputer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                            + "Dodge Ratio: " + currBattle.getComputer().getBaseDodgePercent() + "% <br>";
                    }
                    if(CompHEALZ>0){  
                        currBattle.setComp_curr_hp(currCompHP + CompHEALZ);
                        comp_move_stats += "Your opponent healed for " + CompHEALZ + " Health Points!<br>";
                    }


                }else{
                    comp_move_stats += "Your opponent missed.<br>"
                        + "Base DMG: " + currBattle.getComputer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getComputer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getComputer().getBaseDodgePercent() + "% <br>"
                        + "Crit Ratio: " + currBattle.getComputer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                        + "Crit DMG: " + currBattle.getComputer().getBaseCritDmgBonus() + "DMG <br>";
                }

                comp_move_stats +="Strength: " + currBattle.getComputer().getStr() 
                    + " xxx Accuracy: " + currBattle.getComputer().getAcc() + "<br>"
                    + "Speed: " + currBattle.getComputer().getSpeed()
                    + " xxxxx Skill: " + currBattle.getComputer().getSkill() + "<br>"
                    + " x Knowledge: " + currBattle.getComputer().getKnow() + " x <br>"; 
                currBattle.setTurn(true);
            }        

            //Check if Over :: Else Process Second Side of Battle
            if(currBattle.getPlayer_curr_hp()<=0 || currBattle.getComp_curr_hp()<=0){
                if(currBattle.getPlayer_curr_hp()<=0){
                    win_msg += "You've been vanquished!";
                    currBattle.setPlayer_curr_hp(0);
                    currBattle.setWinner(-1);
                }else{
                    win_msg += "You have vanquished the enemy!";
                    currBattle.setComp_curr_hp(0);
                    currBattle.setWinner(1);
                }            
            }else{
                currCompHP = currBattle.getComp_curr_hp();
                currPlyrHP = currBattle.getPlayer_curr_hp();        

                if(currBattle.isTurn()){            
                if(currBattle.getPlayerHit() >= toHit){
                    int plyrDMG = currBattle.getDamageDone();
                    int plyrHEALZ = currBattle.getHealsDone();
                    plyr_move_stats = "The Attack Landed!<br>";

                    if(currBattle.getPlayerCrit() >= toCrit){
                        plyrDMG += currBattle.getPlayer().getBaseCritDmgBonus();
                        plyr_move_stats += "Critical Strike! <br>"
                            + "Crit Ratio: " + currBattle.getPlayer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                            + "Crit DMG: " + currBattle.getPlayer().getBaseCritDmgBonus() + "DMG <br>";                   
                    }

                    if(plyrDMG>0){                 
                        currBattle.setComp_curr_hp(currCompHP - plyrDMG);
                        plyr_move_stats += "Your attack did " + plyrDMG + " DMG! " +"<br>"
                        + "Base DMG: " + currBattle.getPlayer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getPlayer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getPlayer().getBaseDodgePercent() + "% <br>";
                    }                
                    if(plyrHEALZ>0){
                         currBattle.setPlayer_curr_hp(currPlyrHP + plyrHEALZ);
                         plyr_move_stats += "You healed for " + plyrHEALZ + " Health Points!<br>";
                    }                     
                }else{
                    plyr_move_stats += "You missed.<br>"
                        + "Base DMG: " + currBattle.getPlayer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getPlayer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getPlayer().getBaseDodgePercent() + "% <br>"
                        + "Crit Ratio: " + currBattle.getPlayer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                        + "Crit DMG: " + currBattle.getPlayer().getBaseCritDmgBonus() + "DMG <br>";
                }

                plyr_move_stats += "<br> Strength: " + currBattle.getPlayer().getStr() 
                    + " xxx Accuracy: " + currBattle.getPlayer().getAcc() + "<br>"
                    + "Speed: " + currBattle.getPlayer().getSpeed()
                    + " xxxxx Skill: " + currBattle.getPlayer().getSkill() + "<br>"
                    + " x Knowledge: " + currBattle.getPlayer().getKnow() + " x <br>";

                currBattle.setTurn(false);
            }else{
                if(currBattle.getComputerHit() >= toHit){
                    int CompDMG = currBattle.getDamageDone();
                    int CompHEALZ = currBattle.getHealsDone();
                    comp_move_stats += "The Attack Landed!<br>";

                    if(currBattle.getComputerCrit() >= toCrit){                    
                        CompDMG += currBattle.getComputer().getBaseCritDmgBonus();
                        comp_move_stats += "Critical Strike! <br>"
                            + "Crit Ratio: " + currBattle.getComputer().getBaseCritPercent() + "% Crit: " + toCrit +" <br>"
                            + "Crit DMG: " + currBattle.getComputer().getBaseCritDmgBonus() + "DMG <br>";                    
                    }

                    if(CompDMG>0){ 
                        currBattle.setPlayer_curr_hp(currPlyrHP - CompDMG);
                        comp_move_stats += "Computer attack did " + CompDMG + " DMG! " +"<br>"
                            + "Base DMG: " + currBattle.getComputer().getBaseDmg() + "DMG <br>"
                            + "Hit Ratio : " + currBattle.getComputer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                            + "Dodge Ratio: " + currBattle.getComputer().getBaseDodgePercent() + "% <br>";
                    }
                    if(CompHEALZ>0){  
                        currBattle.setComp_curr_hp(currCompHP + CompHEALZ);
                        comp_move_stats += "Your opponent healed for " + CompHEALZ + " Health Points!<br>";
                    }


                }else{
                    comp_move_stats += "Your opponent missed.<br>"
                        + "Base DMG: " + currBattle.getComputer().getBaseDmg() + "DMG <br>"
                        + "Hit Ratio : " + currBattle.getComputer().getBaseHitPercent() + "% Hit: " + toHit +" <br>"
                        + "Dodge Ratio: " + currBattle.getComputer().getBaseDodgePercent() + "% <br>"
                        + "Crit Ratio: " + currBattle.getComputer().getBaseCritPercent() + "% <br>"
                        + "Crit DMG: " + currBattle.getComputer().getBaseCritDmgBonus() + "DMG <br>";
                }

                comp_move_stats +="Strength: " + currBattle.getComputer().getStr() 
                    + " xxx Accuracy: " + currBattle.getComputer().getAcc() + "<br>"
                    + "Speed: " + currBattle.getComputer().getSpeed()
                    + " xxxxx Skill: " + currBattle.getComputer().getSkill() + "<br>"
                    + " x Knowledge: " + currBattle.getComputer().getKnow() + " x <br>"; 
                    currBattle.setTurn(true);
                }
            
            
                //Check Again for Battle Completion
                if(currBattle.getPlayer_curr_hp()<=0 || currBattle.getComp_curr_hp()<=0){
                    if(currBattle.getPlayer_curr_hp()<=0){
                        win_msg += "You've been vanquished!";
                        currBattle.setPlayer_curr_hp(0);
                        currBattle.setWinner(-1);
                    }else{
                        win_msg += "You have vanquished the enemy!";
                        currBattle.setComp_curr_hp(0);
                        currBattle.setWinner(1);
                    }                
                }
            }
        
            //Comp && Player HP Percent Calculated for Fill Bar
            compPercentHP = (int)((double)(currBattle.getComp_curr_hp() / (double) currBattle.getComputer().getHealthPoints()) * 100.00);
            plyrPercentHP = (int)((double)(currBattle.getPlayer_curr_hp() / (double) currBattle.getPlayer().getHealthPoints()) * 100.00);
            request.getSession().setAttribute("compPercentHP", compPercentHP);
            request.getSession().setAttribute("plyrPercentHP", plyrPercentHP);            
            
            //POST BATTLE EXPERIENCE CALCULATION
            if(currBattle.getWinner() != 0){
                currBattle.removeAlterOpponent();
                currBattle.removeAlterPlayer();
                URL = "/postBattleScreen.jsp";

                double char_earned_xp;
                double acc_earned_xp;
                double diffModifier = 0;

                switch(currBattle.getComputer().getDiff_level()){
                    case "beginner":
                        diffModifier = levelXPTable.get(currBattle.getPlayer().getChar_Level()).getBeginner();
                        break;
                    case "apprentice":
                        diffModifier = levelXPTable.get(currBattle.getPlayer().getChar_Level()).getApprentice();
                        break;
                    case "master":
                        diffModifier = levelXPTable.get(currBattle.getPlayer().getChar_Level()).getMaster();
                        break;
                    case "boss":
                        diffModifier = levelXPTable.get(currBattle.getPlayer().getChar_Level()).getBoss();
                        break;
                    default:
                        err_msg += "No Proper Difficulty Level Found. <br>";
                        break;            
                }

                switch (currBattle.getWinner()) {
                    case 1:
                        char_earned_xp = 1.5 * (diffModifier * currBattle.getComputer().getChar_Level());
                        acc_earned_xp = 3.3 * (diffModifier * currBattle.getComputer().getChar_Level());
                        break;
                    case -1:
                        char_earned_xp = 0.5 * (diffModifier * currBattle.getComputer().getChar_Level());
                        acc_earned_xp = 0.75 * (diffModifier * currBattle.getComputer().getChar_Level());
                        break;
                    default:
                        char_earned_xp = 0;
                        acc_earned_xp = 0;
                        break;
                }

                double char_current_XP = a.getActiveChamp().getExp();
                double char_current_totalXP = a.getActiveChamp().getTotalExp();                    
                double acc_current_XP = a.getExp();
                double acc_current_totalXP = a.getTotalExp();

                exp_msg += a.getActiveChamp().getName() + " gained " + char_earned_xp + " xp!<br>";
                exp_msg += "You gained " + acc_earned_xp + " xp!<br>";

                char_current_XP += char_earned_xp;
                char_current_totalXP += char_earned_xp;                    
                acc_current_XP += acc_earned_xp;
                acc_current_totalXP += acc_earned_xp;                    

                a.getActiveChamp().setTotalExp(char_current_totalXP);                   
                a.setTotalExp(acc_current_totalXP);

                if(char_current_XP >= a.getActiveChamp().getExpAtNext()){
                    charLeveled = true;
                    char_current_XP -= a.getActiveChamp().getExpAtNext();                                               
                    a.getActiveChamp().setExp(char_current_XP);
                    exp_msg += a.getActiveChamp().getName() + " leveled up!<br>";                        
                }else{
                    charLeveled = false;
                    a.getActiveChamp().setExp(char_current_XP);
                }

                if(acc_current_XP >= a.getExpAtNext()){
                    accLeveled = true;
                    acc_current_XP -= a.getExpAtNext();                      
                    a.setExp(acc_current_XP);
                    exp_msg += "You leveled up!<br>";                        
                }else{
                    accLeveled = false;
                    a.setExp(acc_current_XP);
                }                
            }    
        }       
        
        request.getSession().setAttribute("currBattle", currBattle);
        request.getSession().setAttribute("acct", a);
        
        request.setAttribute("clvl", charLeveled);
        request.setAttribute("alvl", accLeveled);
        
        request.setAttribute("err_msg", err_msg);
        request.setAttribute("plyr_move_stats", plyr_move_stats);
        request.setAttribute("comp_move_stats", comp_move_stats);
        request.setAttribute("win_msg", win_msg);
        request.setAttribute("exp_msg", exp_msg);
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);
    }  
    
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
