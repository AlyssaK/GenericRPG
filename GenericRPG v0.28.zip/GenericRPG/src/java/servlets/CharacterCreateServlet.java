package servlets;

import business.*;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Alyssa
 */
public class CharacterCreateServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        final String attribute_error = "Attribute Cannot be Greater Than 25 or Less Than 0. <br>";
        final int starting_points = 25;

        String URL = "/createCharacter.jsp";
        String Amsg = "";
        String Cmsg = "";
        String Emsg = "";        
       
        int str=0, acc=0, spd=0, skl=0, kno=0;
        String photo_choice;
        String photo_loc = "";
        String charName= "";
        
        Account a = (Account) request.getSession().getAttribute("acct");
        List<LevelXPObject> levelXPTable = (List<LevelXPObject>) request.getSession().getAttribute("levelXPTable");
        
        try{                
            charName = request.getParameter("char_name");
            if(Champion_DB.checkChampionName(charName)) {                
                Cmsg += "You Already Have a Character with that Name! <br>";
            }        
        }catch(Exception e){
            Emsg += "GeneralError-1: " + e.getMessage() + "<br>";
        }       
        
        try{
            str = Integer.parseInt(request.getParameter("strength"));
            if(str > 25 || str < 0){
                Cmsg += attribute_error;
            }            
        }catch(NumberFormatException e){
            Emsg += "GeneralError-2: " +  e.getMessage() + "<br>";                    
        }
        
        try{
            acc = Integer.parseInt(request.getParameter("accuracy"));
            if(acc > 25 || acc < 0){
                Cmsg += attribute_error;
            }            
        }catch(NumberFormatException e){
            Emsg += "GeneralError-3: " +  e.getMessage() + "<br>";                    
        }
        
        try{
            spd = Integer.parseInt(request.getParameter("speed"));
            if(spd > 25 || spd < 0){
                Cmsg += attribute_error;
            }            
        }catch(NumberFormatException e){
            Emsg += "GeneralError-4: " +  e.getMessage() + "<br>";                    
        }
        
        try{
            skl = Integer.parseInt(request.getParameter("skill"));
            if(skl > 25 || skl < 0){
                Cmsg += attribute_error;
            }            
        }catch(NumberFormatException e){
            Emsg += "GeneralError-5: " +  e.getMessage() + "<br>";                    
        }
        
        try{
            kno = Integer.parseInt(request.getParameter("knowledge"));
            if(kno > 25 || kno < 0){
                Cmsg += attribute_error;
            }            
        }catch(NumberFormatException e){
            Emsg += "GeneralError-6: " +  e.getMessage() + "<br>";                    
        }      
        
        try{
            photo_choice = request.getParameter("photo");
            switch(photo_choice){
                case "amguy":
                    photo_loc = "images/icons/americanguy.jpg";
                    break;
                case "disco":
                    photo_loc = "images/icons/discodude.jpg";
                    break;
                case "flower":
                    photo_loc = "images/icons/inconspicuousflower.jpg";
                    break;
                case "dragon":
                    photo_loc = "images/icons/scarydragon.jpg";
                    break;
                case "snail":
                    photo_loc = "images/icons/sillysnail.jpg";
                    break;
                case "witch":
                    photo_loc = "images/icons/spookywitch.jpg";
                    break;
                case "horse":
                    photo_loc = "images/icons/stupidhorse.jpg";
                    break;
                case "cat":
                    photo_loc = "images/icons/trickycat.jpg";
                    break;
                default:
                    Emsg += "Error: Unknown Champion Portrait Selected.<br>";
            }
        }catch(Exception e){
            Emsg += "GeneralError-7: " + e.getMessage() + "<br>";
        }
        
        
        if(Cmsg.isEmpty() && Emsg.isEmpty()){
            int temp_total = str + acc + spd + skl + kno;
            if(temp_total!=starting_points){
                Emsg += "Math Error: Your Attributes Do Not Add Up To 25.<br>";
            }else{
                try{
                    Champion c = new Champion(a.getAccountID(), charName, str, acc, spd, skl, kno, 1, 2, 3, 4, photo_loc);
                            c.setChar_Level(1);
                            c.setExp(0);
                            c.setTotalExp(0);
                            c.setBeg_wins(0);
                            c.setBeg_losses(0);
                            c.setApp_wins(0);
                            c.setApp_losses(0);
                            c.setMaster_wins(0);
                            c.setMaster_losses(0);
                            c.setBoss_wins(0);
                            c.setBoss_losses(0);
                            c.setExpAtNext(levelXPTable.get(1).getChampXPtoNext());
                            c.setTotalExpAtNext(levelXPTable.get(1).getChampTotalXP());
                            
                    Cmsg = Champion_DB.addNewChampion(c);
                    a.getChampions().add(c);
                    request.getSession().setAttribute("acct", a);
                    URL = "/viewChampions.jsp";                    
                }catch(Exception e){
                    Emsg += "GeneralError-8: " + e.getMessage() + "<br>";
                }
            }
        }
        
        request.setAttribute("Amsg", Amsg);
        request.setAttribute("Emsg", Emsg);
        request.setAttribute("Cmsg", Cmsg);        

        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
