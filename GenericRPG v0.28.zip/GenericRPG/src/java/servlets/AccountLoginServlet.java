package servlets;

import business.*;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Alyssa
 */

public class AccountLoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String Amsg = "";
        String Cmsg = "";
        String Emsg = "";
        String URL = "/homeAccount.jsp";
        
        Account a = null;
        String acct_name;
        String pwdAttempt;        
        
        List<Post> accPosts;
        List<Action> allActions;
        List<Champion> accountChampions;
        List<LevelXPObject> levelXPTable;        
        
        try{
            acct_name = request.getParameter("acct_name");
            pwdAttempt = request.getParameter("password"); 

            a = Account_DB.getAccount(acct_name);
            a.setPwdAttempt(pwdAttempt);
        }catch(Exception e){
            Emsg += "GET Error: " + e.getMessage() + "<br>";
        }
               
        if(a!=null && a.isAccountAuthen()){
            Amsg = "Authenticated!<br>";
            
            try{              
                //LoadActionsTable && Save to Session Object
                allActions = Action_DB.getAllActions();
                request.getSession().setAttribute("allActions", allActions);
                
                //LoadXPTable -- SetAccountVariables -- Save to Session Object
                levelXPTable = LevelXPObject_DB.loadLevelXPTable();
                request.getSession().setAttribute("levelXPTable", levelXPTable);
                if(!levelXPTable.isEmpty()){
                    a.setTotalExpAtNext(levelXPTable.get(a.getLevel()).getAccountTotalXP());
                    a.setExpAtNext(levelXPTable.get(a.getLevel()).getAccountXPtoNext());
                    Amsg += "XP to Next Loaded!<br>";
                }else{
                    Amsg += "XP To Next Load Error!<br>";
                }
                
                //Load && Check Account Posts Table                
                accPosts = Post_DB.getAccountPosts(a.getAccountID());
                if(!accPosts.isEmpty()){ 
                    a.setPosts(accPosts);
                    Amsg+= a.getPosts().size() + " posts loaded!<br>";
                }
                
                //Load && Check Account Champions Table
                accountChampions = Champion_DB.getChampions(a.getAccountID());
                if(!accountChampions.isEmpty()){ 
                    a.setChampions(accountChampions);
                    Cmsg += a.getChampions().size() + " champions loaded!<br>";
                    for (Champion ch : a.getChampions()) {
                        ch.buildCombatant();
                        ch.setExpAtNext(levelXPTable.get(ch.getChar_Level()).getChampXPtoNext());
                        ch.setTotalExpAtNext(levelXPTable.get(ch.getChar_Level()).getChampTotalXP());
                        if(ch.getId() == a.getActiveChampID()){ 
                            a.setActiveChamp(ch); 
                            Cmsg += a.getActiveChamp().getName() + " is your Active Champion!<br>";
                        }
                    }
                }
                
                request.getSession().setAttribute("acct", a);
            }catch(Exception e){
             Emsg += "Build Error: " + e.getMessage() + "<br>";
            }         
        } else{
            Emsg += "Incorrect Password/Name! <br>";
        }                                   
        
        request.setAttribute("Amsg", Amsg);
        request.setAttribute("Cmsg", Cmsg);
        request.setAttribute("Emsg", Emsg);
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
