package servlets;

import business.*;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Alyssa
 */
public class AccountCreateServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");        
        
        String URL = "/createAccount.jsp";
        String Emsg = "";
        String Amsg = "";        
        String name_attempt = "";
        String password = "";
        String check_password = "";
        String email = "";
        
        try{
            name_attempt = request.getParameter("acct_name");
            password = request.getParameter("password");
            check_password = request.getParameter("passwordc");
            email = request.getParameter("email");
            if(email.isEmpty()){ email = "none given"; }           
        }catch(Exception e){
            Emsg += "Get-Error: " + e.getMessage();
        }
        
        if(password.equalsIgnoreCase(check_password)){       
            try{
                if(Account_DB.checkAccountName(name_attempt)) {                
                    Amsg += "Error: Account Name Has Already Been Chosen! <br>";                    
                }else{
                    Account a = new Account();
                    a.setActiveChampID(0);
                    a.setEmail(email);
                    a.setExp(0);
                    a.setLevel(1);
                    a.setName(name_attempt);
                    a.setPassword(password);
                    a.setPrivileges(1);
                    a.setTotalExp(0);
                    a.setOnline(false);
                    
                    Amsg += Account_DB.addNewAccount(a);
                    URL = "/homeAccount.jsp";
                }           
            }catch(Exception e){
                Emsg += "GeneralError: " + e.getMessage() + "<br>";
            }
        }else{
            Emsg += "Error: Passwords Do Not Match";            
        }       
        
        request.setAttribute("Emsg", Emsg);
        request.setAttribute("Amsg", Amsg);
        
        Cookie uid = new Cookie("acctName", name_attempt);
            uid.setMaxAge(60 * 10);
            uid.setPath("/");
            response.addCookie(uid);        
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
