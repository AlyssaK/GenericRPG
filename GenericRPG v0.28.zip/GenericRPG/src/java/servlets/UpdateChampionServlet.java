package servlets;

import business.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Alyssa
 */
public class UpdateChampionServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        final int points_per_level = 25;
        
        //Get Session Objects - Account & CurrBattle
        Battle currBattle = (Battle) request.getSession().getAttribute("currBattle");        
        Account a = (Account) request.getSession().getAttribute("acct");
        
        String Cmsg = "";
        String Amsg = "";
        String Emsg = "";        
        String URL = "/postBattleScreen.jsp";
        
        int str=0, acc=0, spd=0, skl=0, kno=0;
        int temp_total;
        boolean charLeveled = false;
        boolean accLeveled = false;
        int currALVL = a.getLevel();
        int currCLVL = a.getActiveChamp().getChar_Level();
        
        try{
            charLeveled = (Boolean) request.getSession().getAttribute("clvl");
            accLeveled = (Boolean) request.getSession().getAttribute("alvl");
        }catch(Exception e){
            Emsg += "Error: " + e.getMessage();
        }        
        
        if(charLeveled){
            try{
                str = Integer.parseInt(request.getParameter("strength"));
                if(str > 25 || str < 0){
                    Emsg += "FormatError: Attribute Cannot be Greater Than 25 or Less Than 0.<br>";                    
                }            
            }catch(NumberFormatException e){
                Emsg += "Error: " +  e.getMessage() + "<br>";               
            }

            try{
                acc = Integer.parseInt(request.getParameter("accuracy"));
                if(acc > 25 || acc < 0){
                    Emsg += "FormatError: Attribute Cannot be Greater Than 25 or Less Than 0.<br>";                    
                }            
            }catch(NumberFormatException e){
                Emsg += "Error: " +  e.getMessage() + "<br>";                
            }

            try{
                spd = Integer.parseInt(request.getParameter("speed"));
                if(spd > 25 || spd < 0){
                    Emsg += "Format Error: Attribute Cannot be Greater Than 25 or Less Than 0.<br>";                    
                }            
            }catch(NumberFormatException e){
                Emsg += "Error: " +  e.getMessage() + "<br>";               
            }

            try{
                skl = Integer.parseInt(request.getParameter("skill"));
                if(skl > 25 || skl < 0){
                    Emsg += "Format Error: Attribute Cannot be Greater Than 25 or Less Than 0.<br>";                    
                }            
            }catch(NumberFormatException e){
                Emsg += " General Error: " +  e.getMessage() + "<br>";                
            }

            try{
                kno = Integer.parseInt(request.getParameter("knowledge"));
                if(kno > 25 || kno < 0){
                    Emsg += "Format Error: Number Cannot be Greater Than 25 or Less Than 0.<br>";                    
                }            
            }catch(NumberFormatException e){
                Emsg += "General Error: " +  e.getMessage() + "<br>";                
            }
        }

        if(charLeveled){
            temp_total = str + acc + spd + skl + kno;
            if(temp_total != points_per_level){                
                Emsg += "Error: Check Your Math! Your Attributes Do Not Add Up To 25.<br>";                
            }else{
                currCLVL++;
                a.getActiveChamp().setChar_Level(currCLVL);
                a.getActiveChamp().setStr(a.getActiveChamp().getStr() + str);
                a.getActiveChamp().setAcc(a.getActiveChamp().getAcc() + acc);
                a.getActiveChamp().setSpeed(a.getActiveChamp().getSpeed() + spd);
                a.getActiveChamp().setSkill(a.getActiveChamp().getSkill() + skl);
                a.getActiveChamp().setKnow(a.getActiveChamp().getKnow() + kno);
            }
        }
        
        if(accLeveled){
            currALVL++;
            a.setLevel(currALVL);
        }
            
        switch(currBattle.getComputer().getDiff_level()){
            case "beginner":
                switch (currBattle.getWinner()) {
                    case 1:
                        int tempWins = a.getActiveChamp().getBeg_wins();
                        tempWins++;
                        a.getActiveChamp().setBeg_wins(tempWins);
                        break;
                    case -1:
                        int tempLosses = a.getActiveChamp().getBeg_losses();
                        tempLosses++;
                        a.getActiveChamp().setBeg_losses(tempLosses);
                        break;
                    default:
                        Emsg+= "Unknown Error: Battle Has No Winner.";
                        break;
                }
                        break;
            case "apprentice":
                switch (currBattle.getWinner()) {
                    case 1:
                        int tempWins = a.getActiveChamp().getApp_wins();
                        tempWins++;
                        a.getActiveChamp().setApp_wins(tempWins);
                        break;
                    case -1:
                        int tempLosses = a.getActiveChamp().getApp_losses();
                        tempLosses++;
                        a.getActiveChamp().setApp_losses(tempLosses);
                        break;
                    default:
                        Emsg+= "Unknown Error: Battle Has No Winner.";
                        break;
                }
                        break;
            case "master":
                switch (currBattle.getWinner()) {
                    case 1:
                        int tempWins = a.getActiveChamp().getMaster_wins();
                        tempWins++;
                        a.getActiveChamp().setMaster_wins(tempWins);
                        break;
                    case -1:
                        int tempLosses = a.getActiveChamp().getMaster_losses();
                        tempLosses++;
                        a.getActiveChamp().setMaster_losses(tempLosses);
                        break;
                    default:
                        Emsg+= "Unknown Error: Battle Has No Winner.";                        
                        break;
                }
                        break;
            case "boss":
                switch (currBattle.getWinner()) {
                    case 1:
                        int tempWins = a.getActiveChamp().getBoss_wins();
                        tempWins++;
                        a.getActiveChamp().setBoss_wins(tempWins);
                        break;
                    case -1:
                        int tempLosses = a.getActiveChamp().getBoss_losses();
                        tempLosses++;
                        a.getActiveChamp().setBoss_losses(tempLosses);
                        break;
                    default:
                        Emsg+= "Unknown Error: Battle Has No Winner.";
                        URL = "/after_battle.jsp";
                        break;
                }
                        break;
            default:
                Emsg+= "Unknown Error: Battle Has No Difficuly.";
                break;
        }        
        
        if(Emsg.isEmpty()){
            try{
                Cmsg += Champion_DB.syncChampion(a.getActiveChamp());
                URL = "/homeAccount.jsp";
            }catch(Exception e){
                Emsg += "GeneralError: " + e.getMessage();
            }         
        }
        
        request.getSession().setAttribute("acct", a);        
        
        request.setAttribute("Emsg", Emsg);
        request.setAttribute("Cmsg", Cmsg);
        request.setAttribute("Amsg", Amsg);
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(URL);
        disp.forward(request, response);        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
