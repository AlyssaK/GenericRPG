package business;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author Alyssa
 */

@Entity
@Table(name = "opponent")
@AttributeOverrides( {
    @AttributeOverride(name="id", column=@Column(name="opponent_id")),        
    @AttributeOverride(name="name", column=@Column(name="opponent_name")),
    @AttributeOverride(name="str", column=@Column(name="opp_strength")),
    @AttributeOverride(name="acc", column=@Column(name="opp_accuracy")),
    @AttributeOverride(name="speed", column=@Column(name="opp_speed")),
    @AttributeOverride(name="skill", column=@Column(name="opp_skill")),
    @AttributeOverride(name="know", column=@Column(name="opp_knowledge")),
    @AttributeOverride(name="char_level", column=@Column(name="opp_level")),
    @AttributeOverride(name="actionID1", column=@Column(name="opp_action_1")),
    @AttributeOverride(name="actionID2", column=@Column(name="opp_action_2")),
    @AttributeOverride(name="actionID3", column=@Column(name="opp_action_3")),
    @AttributeOverride(name="actionID4", column=@Column(name="opp_action_4")),
    @AttributeOverride(name="photo_loc", column=@Column(name="opp_portrait"))
} )
public class Opponent extends Generic_Combatant{
    @Column(name="opp_difficulty_level")
    private String diff_level;
    
    public Opponent(){
        super();
        this.diff_level = "";       
    }    
   
    public Opponent(int id, String n, int st, int ac, int sp, int sk, int kn, int lvl,
            int ai1, int ai2, int ai3, int ai4, String dl, String pl){
        super(id, n, st, ac, sp, sk, kn, lvl, ai1, ai2, ai3, ai4, pl);
        this.diff_level = dl;
        ;
    }

    public String getDiff_level() {
        return diff_level;
    }

    public void setDiff_level(String diff_level) {
        this.diff_level = diff_level;
    }

}