/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class Account_DB {
    public static Account getAccount(String name){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT a FROM Account a " +
                    " WHERE a.name = :name ";        
        
        TypedQuery<Account> tq = em.createQuery(jpql, Account.class);        
        tq.setParameter("name", name);
        
        Account a = null;
        
        try{
            a = tq.getSingleResult();            
        }catch(NoResultException e){
            a = null;
        }finally {
            em.close();
        }
        
        return a;
    }
    
    public static boolean checkAccountName(String name){
        boolean used = false;
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT a FROM Account a " +
                    " WHERE a.name = :name ";        
        
        TypedQuery<Account> tq = em.createQuery(jpql, Account.class);        
        tq.setParameter("name", name);
        
        Account a;
        
        try{
            a = tq.getSingleResult();
            used = true;
        }catch(NoResultException e){
            used = false;
        }finally {
            em.close();
        }     
        
        return used;
    }
    
    
    public static String syncAccount(Account a){
        String msg = "";
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();     
        
        try{
            trans.begin();
            em.merge(a);
            trans.commit();
            msg = "Account Synced!!!";
        }catch(Exception e){
            trans.rollback();
            msg = "Account Syncing Error: " + e.getMessage();
        }finally {
            em.close();
        }
               
        return msg;
    }
    
    public static String addNewAccount(Account a){
        String msg = "";
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();     
        
        try{
            trans.begin();
            em.persist(a);
            trans.commit();
            em.refresh(a);
            msg = "Account Synced!!!";
        }catch(Exception e){
            trans.rollback();
            msg = "Account Syncing Error: " + e.getMessage();
        }finally {
            em.close();
        }
               
        return msg;
    }
}
