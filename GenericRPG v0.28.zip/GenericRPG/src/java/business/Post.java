/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.Calendar;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Alyssa
 */
@Entity
@Table(name = "posts")
public class Post {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="post_ID")
    private int id;
    
    @Column(name="post_accountID")
    private int accID;
    
    @Column(name="post_accountName")
    private String accName;
    
    @Column(name="post_date")
    @Temporal(TemporalType.DATE)
    private Date date;
    
    @Column(name="post_text")
    private String text;
    
    
    
    public Post(){
        this.id = 0;
        this.accID = 0;
        this.accName = "";
        this.date = new Date(Calendar.getInstance().getTime().getTime());
    }
    
    public Post(String t, int aid, String n){
        this.id = 0;
        this.accID = aid;
        this.accName = n;
        this.date = new Date(Calendar.getInstance().getTime().getTime());       
        this.text = t;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getAccID() {
        return accID;
    }

    public void setAccID(int accID) {
        this.accID = accID;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
