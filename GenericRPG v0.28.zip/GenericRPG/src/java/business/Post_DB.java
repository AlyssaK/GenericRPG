/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class Post_DB {
    public static List<Post> getAccountPosts(int aID){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT p FROM Post p " +
                    " WHERE p.accID = :aID " +        
                    " ORDER BY p.date desc";
        
        TypedQuery<Post> tq = em.createQuery(jpql, Post.class);        
        tq.setParameter("aID", aID);
        
        List<Post> posts = null;
        
        try{
            posts = tq.getResultList();            
        }catch(NoResultException e){
            posts = null;
        }finally {
            em.close();
        }
        
        return posts;
    }
    
    public static String addNewPost(Post p){
        String msg = "";
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();       
        
        try{
            trans.begin();
            em.persist(p);
            trans.commit();
            em.refresh(p);
            msg = "Posted!<br>";
        }catch(Exception e){
            trans.rollback();
            msg = "Posting Error: " + e.getMessage() + "<br>";
        }finally {
            em.close();
        }
               
        return msg;
    }
}
