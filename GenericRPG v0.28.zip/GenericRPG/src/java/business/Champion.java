package business;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Alyssa
 */
@Entity
@Table(name = "champion")
@AttributeOverrides( {
    @AttributeOverride(name="id", column=@Column(name="character_id")),        
    @AttributeOverride(name="name", column=@Column(name="character_name")),
    @AttributeOverride(name="str", column=@Column(name="char_strength")),
    @AttributeOverride(name="acc", column=@Column(name="char_accuracy")),
    @AttributeOverride(name="speed", column=@Column(name="char_speed")),
    @AttributeOverride(name="skill", column=@Column(name="char_skill")),
    @AttributeOverride(name="know", column=@Column(name="char_knowledge")),
    @AttributeOverride(name="char_level", column=@Column(name="char_level")),
    @AttributeOverride(name="actionID1", column=@Column(name="char_action_1")),
    @AttributeOverride(name="actionID2", column=@Column(name="char_action_2")),
    @AttributeOverride(name="actionID3", column=@Column(name="char_action_3")),
    @AttributeOverride(name="actionID4", column=@Column(name="char_action_4")),
    @AttributeOverride(name="photo_loc", column=@Column(name="char_portrait"))
} )
public class Champion extends Generic_Combatant{
    @Column(name="account_id")
    private int accountID;
    
    @Column(name="char_exp")
    private double exp;
    
    @Transient
    private double expAtNext;
    
    @Column(name="char_total_exp")
    private double totalExp;
    
    @Transient
    private double totalExpAtNext;
    
    @Column(name="beginner_wins")
    private int beg_wins;
    
    @Column(name="beginner_losses")
    private int beg_losses;
    
    @Column(name="apprentice_wins")
    private int app_wins;
    
    @Column(name="apprentice_losses")
    private int app_losses;
    
    @Column(name="master_wins")
    private int master_wins;
    
    @Column(name="master_losses")
    private int master_losses;
    
    @Column(name="boss_wins")    
    private int boss_wins;
    
    @Column(name="boss_losses")
    private int boss_losses;
    
    //Empty Constructor
    public Champion(){
        super();
        this.accountID = 0;
        this.exp = 0.0;
        this.expAtNext = 0.0;
        this.totalExp = 0.0;
        this.totalExpAtNext = 0.0;
        this.beg_wins = 0;
        this.beg_losses = 0;
        this.app_wins = 0;
        this.app_losses = 0;
        this.master_wins = 0;
        this.master_losses = 0;
        this.boss_wins = 0;
        this.boss_losses = 0;
    }
    
    //Create New Character Constructor
    public Champion(int aid, String n, int st, int ac, int sp, int sk,
            int kn, int ai1, int ai2, int ai3, int ai4, String pl){
        super(n, st, ac, sp, sk, kn, ai1, ai2, ai3, ai4, pl);
        this.accountID = aid;
        this.exp = 0.0;
        this.expAtNext = 0.0;
        this.totalExp = 0.0;
        this.totalExpAtNext = 0.0;
        this.beg_wins = 0;
        this.beg_losses = 0;
        this.app_wins = 0;
        this.app_losses = 0;
        this.master_wins = 0;
        this.master_losses = 0;
        this.boss_wins = 0;
        this.boss_losses = 0;
    }
    
    //Load Existing Character Constructor
    public Champion(int id, int aid, String n, int st, int ac, int sp, int sk,
            int kn, int lvl, int ai1, int ai2, int ai3, int ai4, 
            long xp, long txp, String pl, int bw, int bl, int aw,int al, int mw,
            int ml, int bsw, int bsl){
        super(id, n, st, ac, sp, sk, kn, lvl, ai1, ai2, ai3, ai4, pl);
        this.accountID = aid;        
        this.exp = xp;
        this.totalExp = txp;
        this.expAtNext = 0.0;
        this.totalExpAtNext = 0.0;
        this.beg_wins = bw;
        this.beg_losses = bl;
        this.app_wins = aw;
        this.app_losses = al;
        this.master_wins = mw;
        this.master_losses = ml;
        this.boss_wins = bsw;
        this.boss_losses = bsl;    
    }

    public int getAccountID() {
        return accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }
    
    public double getExp() {
        return exp;
    }

    public void setExp(double exp) {
        this.exp = exp;
    }

    public double getTotalExp() {
        return totalExp;
    }

    public void setTotalExp(double totalExp) {
        this.totalExp = totalExp;
    }   

    public int getBeg_wins() {
        return beg_wins;
    }

    public void setBeg_wins(int beg_wins) {
        this.beg_wins = beg_wins;
    }

    public int getBeg_losses() {
        return beg_losses;
    }

    public void setBeg_losses(int beg_losses) {
        this.beg_losses = beg_losses;
    }

    public int getApp_wins() {
        return app_wins;
    }

    public void setApp_wins(int app_wins) {
        this.app_wins = app_wins;
    }

    public int getApp_losses() {
        return app_losses;
    }

    public void setApp_losses(int app_losses) {
        this.app_losses = app_losses;
    }

    public int getMaster_wins() {
        return master_wins;
    }

    public void setMaster_wins(int master_wins) {
        this.master_wins = master_wins;
    }

    public int getMaster_losses() {
        return master_losses;
    }

    public void setMaster_losses(int master_losses) {
        this.master_losses = master_losses;
    }

    public int getBoss_wins() {
        return boss_wins;
    }

    public void setBoss_wins(int boss_wins) {
        this.boss_wins = boss_wins;
    }

    public int getBoss_losses() {
        return boss_losses;
    }

    public void setBoss_losses(int boss_losses) {
        this.boss_losses = boss_losses;
    }

    public double getExpAtNext() {
        return expAtNext;
    }

    public void setExpAtNext(double expAtNext) {
        this.expAtNext = expAtNext;
    }

    public double getTotalExpAtNext() {
        return totalExpAtNext;
    }

    public void setTotalExpAtNext(double totalExpAtNext) {
        this.totalExpAtNext = totalExpAtNext;
    }
}
