/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class Opponent_DB {
    public static Opponent findOpponent(int oppID){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT o FROM Opponent o " +
                    " WHERE o.id= :oppID ";    
        
        TypedQuery<Opponent> tq = em.createQuery(jpql, Opponent.class);        
        tq.setParameter("oppID", oppID);
        
        Opponent o = null;
        
        try{
            o = tq.getSingleResult();
        }catch(NoResultException e){
            o = null;
        }finally {
            em.close();
        }
        
        return o;
    }
}
