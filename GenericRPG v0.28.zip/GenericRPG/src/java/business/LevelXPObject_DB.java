/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class LevelXPObject_DB {
    public static List<LevelXPObject> loadLevelXPTable(){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT l FROM LevelXPObject l";   
        
        TypedQuery<LevelXPObject> tq = em.createQuery(jpql, LevelXPObject.class);      
        List<LevelXPObject> levelXPTable = null;
        
        try{
            levelXPTable = tq.getResultList();
        }catch(NoResultException e){
            levelXPTable = null;
        }finally {
            em.close();
        }
        
        return levelXPTable;
    }
}
