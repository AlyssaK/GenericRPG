/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class Champion_DB {
    public static List<Champion> getChampions(int accID){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT c FROM Champion c " +
                    " WHERE c.accountID = :accid";    
        
        TypedQuery<Champion> tq = em.createQuery(jpql, Champion.class);        
        tq.setParameter("accid", accID);
        
        List<Champion> champions = null;
        
        try{
            champions = tq.getResultList();
        }catch(NoResultException e){
            champions = null;
        }finally {
            em.close();
        }
        
        return champions;
    }
    
     public static boolean checkChampionName(String name){
        boolean used = false;
        Champion c;
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String jpql = "SELECT c FROM Champion c " +
                    " WHERE c.name = :name ";        
        
        TypedQuery<Champion> tq = em.createQuery(jpql, Champion.class);        
        tq.setParameter("name", name);       
        
        try{
            c = tq.getSingleResult();
            used = true;
        }catch(NoResultException e){
            used = false; 
        }finally {
            em.close();
        }     
        
        return used;
    }
     
    public static String syncChampion(Champion c){
        String msg = "";
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        
        try{
            trans.begin();
            em.merge(c);
            trans.commit();            
            msg = "Champions Synced!";
        }catch(Exception e){
            trans.rollback();
            
            msg = "Update Error: " + e.getMessage();
        }finally {
            em.close();
        }
               
        return msg;
    }
    
    public static String addNewChampion(Champion c){
        String msg = "";
        
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        
        try{
            trans.begin();
            em.persist(c);
            trans.commit();
            em.refresh(c);
            msg = "Champions Synced!";
        }catch(Exception e){
            trans.rollback();
            
            msg = "Update Error: " + e.getMessage();
        }finally {
            em.close();
        }
               
        return msg;
    }
}
