package business;

import static java.lang.Math.pow;
import java.util.ArrayList;


/**
 *
 * @author Alyssa
 */
public class Battle {
    private Champion player;
    private Opponent computer;
    
    private ArrayList<Action> playerActions;
    private ArrayList<Action> compActions;
    
    private Action player_curr_move;
    private Action comp_curr_move;    
      
    private int player_curr_hp;
    private int comp_curr_hp;
    
    private boolean turn; //False = Comp :: True = Player
    private int winner; //-1 = Comp Win :: 0 = Undecided :: 1 = Player Win
    
    //Empty Constructor
    public Battle(){
        this.player = new Champion();
        this.computer = new Opponent();
        
        this.playerActions = new ArrayList<>();
        this.compActions = new ArrayList<>();
        
        this.player_curr_move = new Action();
        this.comp_curr_move = new Action();
        
        this.player_curr_hp = 0;
        this.comp_curr_hp = 0;
        
        this.turn = false;
        this.winner = 0;
    }
    
    //Initiate New Battle Constructor
    public Battle(Champion p, Opponent c, ArrayList<Action> pAs, ArrayList<Action> cAs){
        this.player = p;
        this.computer = c; 
        
        this.playerActions = pAs;
        this.compActions = cAs;
        
        this.player_curr_move = new Action();
        this.comp_curr_move = new Action();
        
        this.player_curr_hp = this.player.getHealthPoints();
        this.comp_curr_hp =  this.computer.getHealthPoints();
        
        this.turn = this.player.getSpeed() >= this.computer.getSpeed();
        this.winner = 0;
    }

    public Champion getPlayer() {
        return player;
    }

    public void setPlayer(Champion player) {
        this.player = player;
    }

    public Opponent getComputer() {
        return computer;
    }

    public void setComputer(Opponent computer) {
        this.computer = computer;
    }

    public int getPlayer_curr_hp() {
        return player_curr_hp;
    }

    public void setPlayer_curr_hp(int player_curr_hp) {
        this.player_curr_hp = player_curr_hp;
    }

    public int getComp_curr_hp() {
        return comp_curr_hp;
    }

    public void setComp_curr_hp(int comp_curr_hp) {
        this.comp_curr_hp = comp_curr_hp;
    }

    public boolean isTurn() {
        return turn;
    }

    public void setTurn(boolean turn) {
        this.turn = turn;
    }    

    public boolean firstStrike(){
        setTurn(this.player.getSpeed() >= this.computer.getSpeed());
        return this.turn;
    }
    
    public int getPlayerHit(){              
        int chance = (int) ((this.player.getBaseHitPercent() + this.player_curr_move.getBaseHitChance())/2);
            chance -= (int) this.computer.getBaseDodgePercent();
        return chance;
    }    
    public int getComputerHit(){       
        int chance = (int) ((this.computer.getBaseHitPercent() + this.comp_curr_move.getBaseHitChance())/2);
            chance -= (int) this.player.getBaseDodgePercent();
        return chance;
    }    
    
    public int getPlayerCrit(){
        int critChance = (int) (player.getBaseCritPercent());
        return critChance;        
    }
    public int getComputerCrit(){
        int critChance = (int) (computer.getBaseCritPercent());
        return critChance;
    }
    
    public int getDamageDone(){
        int TotalDMG;
        
        if(turn){
            TotalDMG = player.getBaseDmg() + player_curr_move.getBaseDMG();
            TotalDMG -= computer.getBaseDmgReduct();
        }else{
            TotalDMG = computer.getBaseDmg() + comp_curr_move.getBaseDMG();            
            TotalDMG -= player.getBaseDmgReduct();
        }
        
        return TotalDMG;
    }
    
    public int getHealsDone(){
        int TotalHeals;
        
        if(turn){
            TotalHeals = player_curr_move.getBaseHEAL();
        }else{
            TotalHeals = comp_curr_move.getBaseHEAL();
        }
        
        return TotalHeals;
    }

    public Action getPlayer_curr_move() {
        return player_curr_move;
    }

    public void setPlayer_curr_move(Action player_curr_move) {
        this.player_curr_move = player_curr_move;
    }

    public Action getComp_curr_move() {
        return comp_curr_move;
    }

    public void setComp_curr_move(Action comp_curr_move) {
        this.comp_curr_move = comp_curr_move;
    }
    
    public void applyAlterOpponent(){        
        if(comp_curr_move.getAlterSTR()>0){
            computer.setStr(computer.getStr() + (comp_curr_move.getAlterSTR() * computer.getChar_Level()));              
        }
        if(comp_curr_move.getAlterSPD()>0){
            computer.setSpeed(computer.getSpeed() + (comp_curr_move.getAlterSPD() * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterSKL()>0){
            computer.setSkill(computer.getSkill() + (comp_curr_move.getAlterSKL() * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterACC()>0){
            computer.setAcc(computer.getAcc() + (comp_curr_move.getAlterACC() * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterKNO()>0){
            computer.setStr(computer.getStr() + (comp_curr_move.getAlterSTR() * computer.getChar_Level()));
        }
        computer.buildCombatant();
    }

    public void applyAlterPlayer() {
        if(player_curr_move.getAlterSTR()>0){
            player.setStr(player.getStr() + (player_curr_move.getAlterSTR() * player.getChar_Level()));              
        }
        if(player_curr_move.getAlterSPD()>0){
            player.setSpeed(player.getSpeed() + (player_curr_move.getAlterSPD() * player.getChar_Level()));
        }
        if(player_curr_move.getAlterSKL()>0){
            player.setSkill(player.getSkill() + (player_curr_move.getAlterSKL() * player.getChar_Level()));
        }
        if(player_curr_move.getAlterACC()>0){
            player.setAcc(player.getAcc() + (player_curr_move.getAlterACC() * player.getChar_Level()));
        }
        if(player_curr_move.getAlterKNO()>0){
            player.setStr(player.getStr() + (player_curr_move.getAlterSTR() * player.getChar_Level()));
        }
        player.buildCombatant();
    }   

    
    public void removeAlterPlayer(){
        if(player_curr_move.getAlterSTR()>0){
            player.setStr(player.getStr() - (player_curr_move.getAlterSTR()* player.getChar_Level()));              
        }
        if(player_curr_move.getAlterSPD()>0){
            player.setSpeed(player.getSpeed() - (player_curr_move.getAlterSPD()* player.getChar_Level()));
        }
        if(player_curr_move.getAlterSKL()>0){
            player.setSkill(player.getSkill() - (player_curr_move.getAlterSKL() * player.getChar_Level()));
        }
        if(player_curr_move.getAlterACC()>0){
            player.setAcc(player.getAcc() - (player_curr_move.getAlterACC() * player.getChar_Level()));
        }
        if(player_curr_move.getAlterKNO()>0){
            player.setStr(player.getStr() - (player_curr_move.getAlterSTR()* player.getChar_Level()));
        }
        player.buildCombatant();        
    }
    
    public void removeAlterOpponent(){
        if(comp_curr_move.getAlterSTR()>0){
            computer.setStr(computer.getStr() - (comp_curr_move.getAlterSTR()  * computer.getChar_Level()));              
        }
        if(comp_curr_move.getAlterSPD()>0){
            computer.setSpeed(computer.getSpeed() - (comp_curr_move.getAlterSPD() * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterSKL()>0){
            computer.setSkill(computer.getSkill() - (comp_curr_move.getAlterSKL() * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterACC()>0){
            computer.setAcc(computer.getAcc() - (comp_curr_move.getAlterACC()  * computer.getChar_Level()));
        }
        if(comp_curr_move.getAlterKNO()>0){
            computer.setStr(computer.getStr() - (comp_curr_move.getAlterSTR() * computer.getChar_Level()));
        }
        computer.buildCombatant();  
    }
    

    public int getWinner() {
        return winner;
    }

    public void setWinner(int winner) {
        this.winner = winner;
    }

    public ArrayList<Action> getPlayerActions() {
        return playerActions;
    }

    public void setPlayerActions(ArrayList<Action> playerActions) {
        this.playerActions = playerActions;
    }

    public ArrayList<Action> getCompActions() {
        return compActions;
    }

    public void setCompActions(ArrayList<Action> compActions) {
        this.compActions = compActions;
    }
}
