package business;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Alyssa
 */

@Entity
@Table(name = "account")
public class Account {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "account_id")
    private int accountID;
    
    @Column(name = "account_name")
    private String name;
    
    @Column(name = "account_password")
    private String password;
    
    @Transient
    private String pwdAttempt;
    
    @Column(name = "account_email")
    private String email;
    
    @Column(name = "account_activeChampID")
    private int activeChampID;
    
    @Transient
    private Champion activeChamp;
    
    @Column(name = "account_privileges")
    private int privileges;
    
    @Column(name = "account_online")
    private boolean online;
    
    @Column(name = "account_exp")
    private double exp;
    
    @Transient
    private double expAtNext; 
    
    @Column(name = "account_total_exp")
    private double totalExp;
    
    @Transient
    private double totalExpAtNext;  
    
    @Column(name = "account_level")
    private int level;
   
    @OneToMany(fetch=FetchType.EAGER)
    @JoinColumn(name="account_id", insertable=false, updatable=false)
    private List<Champion> champions;
    
    @OneToMany(fetch=FetchType.EAGER)
    @JoinColumn(name="account_id", insertable=false, updatable=false)
    private List<Post> posts;
    
   public Account(){
        this.name = "";
        this.password = "";
        this.pwdAttempt = "";
        this.email = "None Provided";
        this.exp = 0;
        this.expAtNext = 0;
        this.totalExp = 0;
        this.totalExpAtNext = 0;
        this.level = 1;
        this.privileges = 0;
        this.accountID = 0;
        this.activeChampID = 0;
        this.online = false;
        this.champions = null;
        this.posts = null;
        this.activeChamp = new Champion();
    }
   
    public boolean isAccountAuthen() {
        if(!this.password.isEmpty()){
            if(this.password.equals(this.pwdAttempt)){
                return true;
            }
        }        
        return false;
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getPwdAttempt() {
        return pwdAttempt;
    }
    public void setPwdAttempt(String pwdAttempt) {
        this.pwdAttempt = pwdAttempt;
    }
    public int getAccountID() {
        return accountID;
    }
    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }
    public List<Champion> getChampions() {
        return champions;
    }
    public void setChampions(List<Champion> champions) {
        this.champions = champions;
    }
    public Champion getActiveChamp() {
        return activeChamp;
    }
    public void setActiveChamp(Champion activeChamp) {
        this.activeChamp = activeChamp;
    }    
    public int getActiveChampID() {
        return activeChampID;
    }
    public void setActiveChampID(int activeChampID) {
        this.activeChampID = activeChampID;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public boolean isOnline() {
        return online;
    }
    public void setOnline(boolean online) {
        this.online = online;
    }
    public double getExp(){
        return this.exp;
    }    
    public void setExp(double exp) {
        this.exp = exp;
    }
    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    public int getPrivileges() {
        return privileges;
    }
    public void setPrivileges(int privileges) {
        this.privileges = privileges;
    }
    public List<Post> getPosts() {
        return posts;
    }
    public void setPosts(List<Post> posts) {
        this.posts = posts;
    }
    public double getExpAtNext() {
        return expAtNext;
    }
    public void setExpAtNext(double expAtNext) {
        this.expAtNext = expAtNext;
    }
    public double getTotalExp() {
        return totalExp;
    }
    public void setTotalExp(double totalExp) {
        this.totalExp = totalExp;
    }
    public double getTotalExpAtNext() {
        return totalExpAtNext;
    }
    public void setTotalExpAtNext(double totalExpAtNext) {
        this.totalExpAtNext = totalExpAtNext;
    }
}
