/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Alyssa
 */
public class Action_DB {
    public static List<Action> getAllActions(){
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String qS = "SELECT a FROM Action a ";
        TypedQuery<Action> tq = em.createQuery(qS, Action.class);        
        List<Action> allActions;
        
        try{           
            allActions = tq.getResultList();
        }catch(NoResultException e){
            allActions = null;
        }finally {
            em.close();
        }
        
        return allActions;
    }

     public static String addNewAction(Action a){
        String msg = "";
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        
        
        
        try{
            trans.begin();
            em.persist(a);
            trans.commit();
            em.refresh(a);
            msg = "Action Added!";
        }catch(Exception e){
            trans.rollback();
            msg = "Action Creation Error: " + e.getMessage();
        }finally {
            em.close();
        }
               
        return msg;
    }
}
